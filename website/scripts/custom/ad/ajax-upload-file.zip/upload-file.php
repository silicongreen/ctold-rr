<?php
/**
 * Package: Ajax file upload
 *
 * http://www.scriptarticle.com/
 * Author Mahesh <scriptarticle@gmail.com>
 * Date: 2013-02-14 11:31:21 (Thu, 14 Feb 2013)
 */
$uploaddir = 'uploads/'; 
$file = $uploaddir . basename($_FILES['filename']['name']); 
 
if (move_uploaded_file($_FILES['filename']['tmp_name'], $file)) { 
  echo "success"; 
} else {
  echo "error";
}
?>